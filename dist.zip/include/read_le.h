#ifndef READ_LE_H
#define READ_LE_H
#include <stdint.h>

#include "ijvm.h"


uint32_t read_le(const byte_t *data);
#endif /* READ_LE_H */
