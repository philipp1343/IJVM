#ifndef CONSUME_H
#define CONSUME_H
#include <stddef.h>

#include "ijvm.h"


void consume(const byte_t **data, size_t *byte_count);
#endif /* CONSUME_H */
